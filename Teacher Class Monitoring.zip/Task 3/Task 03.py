import time
print ("Hello there! I am 343 Guilty Spark!\nI will assist you to access your classes data.")
time.sleep(2)
finished = False
while finished == False:
    classname = input("What class do you want to view?\n1)Oak\n2)Birch\n3)Spruce\n(Write your answer here): ").title()
    print("Thank you, please wait momentarally while I go fetch your data!")
    time.sleep(2)
    if classname == "1":
        classname = "Oak"
    elif classname == "2":
        classname = "Birch"
    elif classname == "3":
        classname = "Spruce"
    if classname == "Spruce":
        twod = []
        myclass = open('Spruceclass.txt', 'rt')
        for Class in myclass:
            twod.append(eval(Class))
        organisetype = input("How would you like to organise the data...\n1) 'High to Low'\n2) 'Alphabetically'\n3) 'Average'\n").lower()
        if organisetype == "1":
            organised = ("high to low")
        elif organisetype == "2":
            organised = ("alphabetically")
        elif organisetype == "3":
            organised = ("average")
        else:
            organised = organisetype
        if organised == "high to low":
            for data in twod:
                maximum = max(data[1:])
                data.append(maximum)
            sorted_data = sorted(twod, key=lambda maximum:maximum[4],reverse=True)
            for data in sorted_data:
                strdata = (data[0], data[4])
                strdata = str(strdata)
                print (strdata.strip('[()]'))
        elif organised == "alphabetically":
            for data in twod:
                maximum = max(data[1:])
                data.append(maximum)
            sortednames = sorted(twod, key=lambda name:name[0])
            for data in sortednames:
                print(data[0], data [-1])
        elif organised == "average":
            for data in twod:
                average = (data[1] + data[2] + data [3])/3
                data.append(average)
            sorted_data = sorted(twod, key=lambda maximum:maximum[4],reverse=True)
            for data in sorted_data:
                strdata = (data[0], data[4])
                strdata = str(strdata)
                print (strdata.strip('[()]'))
    elif classname == "Birch":
        twod = []
        myclass = open('Birchclass.txt', 'rt')
        for Class in myclass:
            twod.append(eval(Class))
        organisetype = input("How would you like to organise the data...\n1) 'High to Low'\n2) 'Alphabetically'\n3) 'Average'\n").lower()
        if organisetype == "1":
            organised = ("high to low")
        elif organisetype == "2":
            organised = ("alphabetically")
        elif organisetype == "3":
            organised = ("average")
        else:
            organised = organisetype
        if organised == "high to low":
            for data in twod:
                maximum = max(data[1:])
                data.append(maximum)
            sorted_data = sorted(twod, key=lambda maximum:maximum[4],reverse=True)
            for data in sorted_data:
                strdata = (data[0], data[4])
                strdata = str(strdata)
                print (strdata.strip('[()]'))
        elif organised == "alphabetically":
            for data in twod:
                maximum = max(data[1:])
                data.append(maximum)
            sortednames = sorted(twod, key=lambda name:name[0])
            for data in sortednames:
                print(data[0], data[-1])
        elif organised == "average":
            for data in twod:
                average = (data[1] + data[2] + data [3])/3
                data.append(average)
            sorted_data = sorted(twod, key=lambda maximum:maximum[4],reverse=True)
            for data in sorted_data:
                strdata = (data[0], data[4])
                strdata = str(strdata)
                print (strdata.strip('[()]'))
                
    elif classname == "Oak":
        twod = []
        myclass = open('Oakclass.txt', 'rt')
        for Class in myclass:
            twod.append(eval(Class))
        organisetype = input("How would you like to organise the data...\n1) 'High to Low'\n2) 'Alphabetically'\n3) 'Average'\n").lower()
        if organisetype == "1":
            organised = ("high to low")
        elif organisetype == "2":
            organised = ("alphabetically")
        elif organisetype == "3":
            organised = ("average")
        else:
            organised = organisetype
        if organised == "high to low":
            for data in twod:
                maximum = max(data[1:])
                data.append(maximum)
            sorted_data = sorted(twod, key=lambda maximum:maximum[4],reverse=True)
            for data in sorted_data:
                strdata = (data[0], data[4])
                strdata = str(strdata)
                print (strdata.strip('[()]'))
        elif organised == "alphabetically":
            for data in twod:
                maximum = max(data[1:])
                data.append(maximum)
            sortednames = sorted(twod, key=lambda name:name[0])
            for data in sortednames:
                print(data[0], data[-1])
        elif organised == "average":
            for data in twod:
                average = (data[1] + data[2] + data [3])/3
                data.append(average)
            sorted_data = sorted(twod, key=lambda maximum:maximum[4],reverse=True)
            for data in sorted_data:
                strdata = (data[0], data[4])
                strdata = str(strdata)
                print (strdata.strip('[()]'))
        else:
            print ("Error, the command you put in is invalid")
        myclass.close()
    else:
        print ("I'm sorry, that isn't a real class, please try again.")
    review = input("Would you like to view another class? Please type either 'Yes' or 'No'").title()
    if review =="Yes":
        print("Ok, just let me reboot")
        time.sleep(2)
    elif review == "No":
        time.sleep(1)
        print ("Goodbye!")
        time.sleep(2)
        finished = True
    else:
        sure = input("Are you sure you want to leave? Type 'Yes' or 'No'").lower()
        if sure == "yes":
            print ("Goodbye")
            time.sleep(1)
            finished = True
        elif sure == "no":
            print ("Ok, lets get you out of here!")
            time.sleep(1)
        else:
            finished = True
