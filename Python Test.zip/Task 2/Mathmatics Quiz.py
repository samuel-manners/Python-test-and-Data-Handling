import random
import re
import time
#This imports random, re and time from the python's toolbox
continued = True
valuecorrect = False
namevalid = False
#Continued allows the user to restart at the end, valuecorrect makes a lop that allows the user to write the correct number and namevalid enables the loop for checking if the user entered a valid name
print ("Hello and welcome to this quiz!")
while namevalid == False:
    namerule = "[a-zA-Z][a-z]+"
    name = input("To start off with, what is your name!").title()
    if re.search(namerule, name):
        time.sleep(1)
        namevalid = True
        print ("The quiz will start in a few seconds")
        time.sleep (1)
        #This makes sure there is at least some letters in the name
    else:
        print("Name is invalid, please enter a valid name (made with letters).")
errors = 0        
namevalid = False
while namevalid == False:
    Class = input ("What Class are you in?\nOak\nBirch\nSpruce?\n(Enter name here):").title()
    tf = True
    if Class == "Oak":
        namevalid = True
    elif Class == "Birch":
        namevalid = True
    elif Class == "Spruce":
        namevalid = True
    elif Class == "Class Override":
        print ("Class Override is enabled, no record will be kept of this quiz")
        time.sleep(1)
        print("Launching Quiz")
        time.sleep(1)
        namevalid = True
    else:
        print ("Enter your actual class")
        time.sleep(1)
while continued == True:
    #This loop is where the user will be sent back to if they deside to restart
    hard = input("How hard do you want the quiz?\nRemember, anything you type other than the following terms defults it to normal.\n Please write 'Easy', 'Normal', or 'Custom'").lower()
    if hard == "easy":
        topvalue = 10
    elif hard == "normal":
        topvalue = 25
    elif hard == "custom":
        valuecorrect = False
        while valuecorrect == False:
            try:
                topvalue = int(input("Please choose a number above 10 for the highest number in the quiz."))
                if topvalue >9:
                    valuecorrect=True
                else:
                    print ("10 or more please")
            except ValueError:
                print ("Please write as a number")
    else:
        topvalue = 25
        #this sets the level difficulty
    score = 0
    OPERATOR = ["+", "-", "*"]
    #Goes is = 10 and score is equil to 0 to count the score up and have limited goes
    for goes in range (0,10):
        randomNumber1 = random.randint(1,topvalue)
        randomNumber2 = random.randint(1,topvalue-5)
        chosenOperator = random.choice (OPERATOR)
        if chosenOperator == "+" :
            lessthan = True
            while lessthan == True:
                if randomNumber1 < randomNumber2:
                    randomNumber2 = (randomNumber2 - (randomNumber1)+1)
                    errors = errors+1
                    if errors == 3:
                        randomNumber1 = randomNumber1+randomNumber2
                        lessthan = False
                        errors = 0
                    else:
                        errors = errors
                else:
                    lessthan = False
            total = (randomNumber1+randomNumber2)
            #If the operator is chosen it works out what the questions answer is
        elif chosenOperator == "-" :
            lessthan = True
            while lessthan == True:
                if randomNumber1 < randomNumber2:
                    randomNumber2 = (randomNumber2 - (randomNumber1)+1)
                    errors = errors+1
                    if errors == 3:
                        randomNumber1 = randomNumber1+randomNumber2
                        lessthan = False
                        errors = 0
                    else:
                        errors = errors
                else:
                    lessthan = False
            total = (randomNumber1-randomNumber2)
            if total == 0:
                randomNumber1 = ((randomNumber1*2)-2)
            total = (randomNumber1-randomNumber2)
        elif chosenOperator == "*" :
            lessthan = True
            while lessthan == True:
                if randomNumber1 < randomNumber2:
                    randomNumber2 = (randomNumber2 - (randomNumber1)+1)
                    errors = errors+1
                    if errors == 3:
                        randomNumber1 = randomNumber1+randomNumber2
                        lessthan = False
                        errors = 0
                    else:
                        errors = errors
                else:
                    lessthan = False
            total = (randomNumber1*(randomNumber2))
            if total == 0:
                randomNumber1 = ((randomNumber1*2)-2)
        else:
            print ("We are sorry, an error has happened, the answer will follow so you can show your teacher you did it right")
            print (answer)
        print ("What is", randomNumber1, chosenOperator ,randomNumber2, "?   ")
        #This tells the user the question
        valuecorrect = False
        while valuecorrect == False:
            try:
                answer = int(input())
                valuecorrect=True
            except ValueError:
                print ("Please write as a number")
                #This is incase the user writes "five" rather than "5" due to the input area accepts integers only, it tells the user to write a number if they don't write a number
        if answer == total:
            print("Well Done!!!")
            score = score+1
            time.sleep(2)
            #Tells the user they are correct
        else:
            print("Poor Luck, maybe next time!!!")
            print("The actual answer was", total)
            time.sleep(2)
            #tells the user they were wrong
    uploadData = []
    print ("Well done", name, "you got", score, "out of 10!!!")
    time.sleep(1.5)
    #Tells the user there overall score
    print ("This means you got", score/10*100, "percent correct!")
    #Tells the user there percentage score
    time.sleep(1.5)
    print("So", name, "Would you like another go?")
    #Gives the option to restart
    time.sleep(1.5)
    restart = input("Type 'Y' if you would like another go, if not click enter:   ").upper()
    if restart == "Y":
        print("Ok lets restart")
        time.sleep(1)
    elif restart == "YES":
        print ("Ok lets restart")
        time.sleep(1)
        #This enables the user to restart
    else:
        sure = input(str("\n\nAre you sure? \nPress enter if you are sure or type 'y' if you mean't to restart. \n")).lower()
        if sure == "y":
            print ("Ok, I am just restarting the program")
            time.sleep(2)
            continued = True
        else:
            print("Goodbye")
            continued = False
stop = 0
#Task 2 Starts here!
uploadData = []
#This variable will contain all the nessacary data to upload into the .txt file
ended = False
while ended == False:
    if Class == "Oak":
        myFile = open('Oakclass.txt', 'a')
        uploadData.append(name)
        uploadData.append(score)
        myFile.write (str(uploadData) + "\n")
        ended = True
    elif Class == "Birch":
        myFile = open('Birchclass.txt', 'a')
        uploadData.append(name)
        uploadData.append(score)
        myFile.write (str(uploadData) + "\n")
        ended = True
    elif Class == "Spruce":
        myFile = open('Spruceclass.txt', 'a')
        uploadData.append(name)
        uploadData.append(score)
        myFile.write (str(uploadData) + "\n")
        ended = True
    elif Class == "Class Override":
        print ("Due to class override your data has not been uploaded to a file,\ndo you want to test the error capture part of the code or do you want to end the code?")
        errorcapture = input("If you want to finish the code type 'continue' else press enter")
        if errorcapture == "continue":
            time.sleep(1)
            Class = "Overriden Error"
        else:
            ended = True
    else:
        print("Please wait, I am experiencing problems uploading your score.")
        time.sleep(2)
        stop = stop+1
        if stop == 3:
            end = input("We are so sorry, we cannot end the program, do you want to keep trying?").lower()
            if end == "no":
                print ("Goodbye")
                ended = True
            else:
                print("Ok, lets retry!")
                stop = 0

